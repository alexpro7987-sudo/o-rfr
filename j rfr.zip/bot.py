import telebot
import logging
import sys
import time
import json
from pathlib import Path
from config import BOT_TOKEN, ADMIN_IDS, LOGS_PATH, DATA_PATH

Path(LOGS_PATH).mkdir(exist_ok=True)
Path(DATA_PATH).mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(f"{LOGS_PATH}/bot.log", encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)
bot = telebot.TeleBot(BOT_TOKEN, parse_mode="HTML")


class BotManager:
    def __init__(self):
        self.start_time = time.time()
        self.user_data = {}
        self.load_data()

    def load_data(self):
        data_file = Path(f"{DATA_PATH}/users.json")
        if data_file.exists():
            try:
                with open(data_file, 'r', encoding='utf-8') as f:
                    self.user_data = json.load(f)
                logger.info(f"Загружены данные {len(self.user_data)} пользователей")
            except Exception as e:
                logger.error(f"Ошибка загрузки данных: {e}")

    def save_data(self):
        try:
            with open(f"{DATA_PATH}/users.json", 'w', encoding='utf-8') as f:
                json.dump(self.user_data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Ошибка сохранения данных: {e}")


manager = BotManager()


@bot.message_handler(commands=['start'])
def handle_start(message):
    user_id = message.from_user.id
    manager.user_data[str(user_id)] = {
        'username': message.from_user.username,
        'first_name': message.from_user.first_name,
        'last_name': message.from_user.last_name,
        'join_date': time.strftime("%Y-%m-%d %H:%M:%S"),
        'last_activity': time.time()
    }
    manager.save_data()

    welcome_text = f"""👋 Привет, {message.from_user.first_name}!

🤖 Я твой личный бот. Вот что я умею:
/start - Начало работы
/help - Помощь и команды
/stats - Статистика
/about - О боте
/ping - Проверка связи

Просто напиши мне что-нибудь!"""

    bot.send_message(message.chat.id, welcome_text)
    logger.info(f"Новый пользователь: {message.from_user.username} ({user_id})")


@bot.message_handler(commands=['help'])
def handle_help(message):
    help_text = """<b>📋 Доступные команды:</b>

🔹 <code>/start</code> - Запустить бота
🔹 <code>/help</code> - Эта справка
🔹 <code>/stats</code> - Статистика
🔹 <code>/about</code> - Информация о боте
🔹 <code>/ping</code> - Проверка связи

<b>📝 Что можно делать:</b>
• Писать любые сообщения
• Получать ответы
• Использовать кнопки

🔄 <b>Работа бота:</b>
• Автозапуск при старте системы
• Работает 24/7
• Сохраняет данные"""

    bot.send_message(message.chat.id, help_text)


@bot.message_handler(commands=['stats'])
def handle_stats(message):
    if message.from_user.id in ADMIN_IDS:
        uptime = time.time() - manager.start_time
        hours = int(uptime // 3600)
        minutes = int((uptime % 3600) // 60)

        stats_text = f"""<b>📊 Статистика бота</b>

👥 Пользователей: {len(manager.user_data)}
⏱ Время работы: {hours}ч {minutes}м
💾 Данные: Сохранены
📁 Путь: C:\\Users\\Den\\TelegramBotSimple"""

        bot.send_message(message.chat.id, stats_text)
    else:
        bot.send_message(message.chat.id, "Эта команда доступна только администратору.")


@bot.message_handler(commands=['about'])
def handle_about(message):
    about_text = """<b>🤖 Информация о боте</b>

Версия: 2.0
Разработчик: Den
Путь: C:\\Users\\Den\\TelegramBotSimple
Библиотека: pyTelegramBotAPI

<b>Особенности:</b>
✅ Автозапуск при старте Windows
✅ Логирование в файл
✅ Сохранение данных пользователей
✅ Обработка ошибок
✅ Админ-панель

Бот запускается автоматически!"""

    bot.send_message(message.chat.id, about_text)


@bot.message_handler(commands=['ping'])
def handle_ping(message):
    import datetime
    response_time = datetime.datetime.now().strftime("%H:%M:%S")
    bot.reply_to(message, f"🏓 Pong!\nВремя сервера: {response_time}\nБот активен!")


@bot.message_handler(func=lambda message: True)
def handle_all_messages(message):
    user_id = str(message.from_user.id)
    if user_id in manager.user_data:
        manager.user_data[user_id]['last_activity'] = time.time()
        manager.user_data[user_id]['message_count'] = manager.user_data[user_id].get('message_count', 0) + 1
        manager.save_data()

    response = f"✅ <b>Сообщение получено!</b>\n\n📝 Текст: {message.text}\n\n🆔 ID сообщения: {message.message_id}"
    bot.reply_to(message, response)
    logger.info(f"Сообщение от {message.from_user.username}: {message.text[:50]}...")


def main():
    logger.info("=" * 60)
    logger.info("🤖 БОТ ЗАПУСКАЕТСЯ")
    logger.info(f"📁 Путь: C:\\Users\\Den\\TelegramBotSimple")
    logger.info(f"👤 Пользователей в базе: {len(manager.user_data)}")
    logger.info("=" * 60)

    print("=" * 50)
    print("🤖 TELEGRAM BOT v2.0")
    print("📁 Path: C:\\Users\\Den\\TelegramBotSimple")
    print(f"👥 Users: {len(manager.user_data)}")
    print("✅ Ready to receive messages")
    print("=" * 50)

    while True:
        try:
            bot.infinity_polling(timeout=60, long_polling_timeout=60)
        except Exception as e:
            logger.error(f"Ошибка подключения: {e}")
            time.sleep(15)


if __name__ == "__main__":
    main()